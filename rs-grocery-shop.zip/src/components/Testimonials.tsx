import { Star, Quote } from "lucide-react";

type Review = {
  name: string;
  role: string;
  text: string;
  rating: number;
  initial: string;
  tint: string;
};

const REVIEWS: Review[] = [
  {
    name: "सुनीता शर्मा",
    role: "नियमित ग्राहक · 12 वर्षों से",
    text: "RS Grocery से सामान लेना यानी शुद्धता और वजन दोनों की गारंटी। मसाले असली और ताज़े मिलते हैं।",
    rating: 5,
    initial: "सु",
    tint: "oklch(0.85 0.12 85)",
  },
  {
    name: "राजेश गुप्ता",
    role: "पड़ोसी दुकानदार",
    text: "38 साल से भरोसे की दुकान। दालें, चावल और घी हमेशा प्रीमियम क्वालिटी। दाम भी वाजिब।",
    rating: 5,
    initial: "रा",
    tint: "oklch(0.78 0.14 55)",
  },
  {
    name: "प्रिया वर्मा",
    role: "गृहिणी",
    text: "WhatsApp पर ऑर्डर करना बहुत आसान है। समय पर सामान मिल जाता है और स्टाफ बहुत विनम्र है।",
    rating: 5,
    initial: "प्र",
    tint: "oklch(0.8 0.13 30)",
  },
  {
    name: "अजय सिंह",
    role: "पुराने ग्राहक",
    text: "बासमती चावल और देसी घी का स्वाद घर के त्योहारों में जान डाल देता है। हमेशा RS से ही लेता हूँ।",
    rating: 5,
    initial: "अ",
    tint: "oklch(0.78 0.15 110)",
  },
];

export function Testimonials() {
  return (
    <section className="mt-14">
      <div className="mb-6 flex items-end justify-between gap-3">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-[0.18em] text-brand-deep/70">
            ग्राहकों की ज़ुबानी
          </div>
          <h2 className="mt-1 font-display text-2xl font-extrabold text-brand-deep sm:text-3xl">
            हज़ारों परिवारों का भरोसा
          </h2>
        </div>
        <div className="hidden items-center gap-1 rounded-full bg-mustard/30 px-3 py-1.5 text-xs font-bold text-brand-deep sm:inline-flex">
          <Star className="h-3.5 w-3.5 fill-mustard-deep text-mustard-deep" /> 4.9 / 5 · 2000+ रिव्यू
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {REVIEWS.map((r) => (
          <article
            key={r.name}
            className="relative flex h-full flex-col rounded-2xl border border-border bg-card p-5 shadow-soft"
          >
            <Quote className="absolute right-4 top-4 h-6 w-6 text-mustard/60" />
            <div className="mb-3 flex items-center gap-0.5">
              {Array.from({ length: r.rating }).map((_, i) => (
                <Star key={i} className="h-4 w-4 fill-mustard-deep text-mustard-deep" />
              ))}
            </div>
            <p className="flex-1 text-sm leading-relaxed text-foreground/85">“{r.text}”</p>
            <div className="mt-4 flex items-center gap-3 border-t border-border pt-4">
              <div
                className="flex h-10 w-10 items-center justify-center rounded-full font-display text-sm font-extrabold text-foreground"
                style={{ background: r.tint }}
              >
                {r.initial}
              </div>
              <div className="min-w-0">
                <div className="truncate font-display text-sm font-bold text-brand-deep">
                  {r.name}
                </div>
                <div className="truncate text-xs text-muted-foreground">{r.role}</div>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
