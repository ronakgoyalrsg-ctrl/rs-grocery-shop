import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { ShoppingBag, Zap } from "lucide-react";
import { toast } from "sonner";
import type { Product } from "@/data/products";
import { useCart } from "@/lib/cart";
import { ProductImage } from "./ProductImage";
import { QuantityStepper } from "./QuantityStepper";

export function ProductCard({ product }: { product: Product }) {
  const { addToCart, setQty } = useCart();
  const navigate = useNavigate();
  const [qty, setLocalQty] = useState(1);

  const total = product.price * qty;

  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition hover:-translate-y-1 hover:shadow-lift">
      <div className="relative">
        <ProductImage product={product} />
        <div className="absolute right-0 top-3 rounded-l-md bg-mustard px-3 py-1 text-xs font-extrabold text-foreground shadow-sm">
          ₹{product.price}/{product.unit}
        </div>
      </div>
      <div className="flex flex-1 flex-col gap-1 p-4">
        <h3 className="font-display text-base font-bold leading-tight text-foreground">
          {product.nameHi ?? product.name}
        </h3>
        <p className="text-xs text-muted-foreground">{product.name}</p>
        <div className="mt-3 flex items-center justify-between gap-2">
          <QuantityStepper value={qty} onChange={setLocalQty} />
          <div className="text-right">
            <div className="text-[11px] uppercase tracking-wide text-muted-foreground">Total</div>
            <div className="font-display text-base font-extrabold text-brand-deep">₹{total}</div>
          </div>
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => {
              addToCart(product.id, qty);
              toast.success(`${product.name} added to cart`);
            }}
            className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-brand/25 bg-brand/10 px-3 py-2 text-sm font-semibold text-brand-deep transition hover:bg-brand/15"
          >
            <ShoppingBag className="h-4 w-4" /> Add
          </button>
          <button
            type="button"
            onClick={() => {
              setQty(product.id, qty);
              navigate({ to: "/checkout" });
            }}
            className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-brick px-3 py-2 text-sm font-semibold text-primary-foreground transition hover:bg-brick-deep"
          >
            <Zap className="h-4 w-4" /> Buy Now
          </button>
        </div>
      </div>
    </article>
  );
}
