import type { Product } from "@/data/products";

export function ProductImage({ product, size = 104 }: { product: Product; size?: number }) {
  return (
    <div
      className="relative flex items-center justify-center overflow-hidden"
      style={{
        width: "100%",
        height: size,
        background: `linear-gradient(160deg, ${product.tint}, color-mix(in oklab, ${product.tint} 70%, white))`,
      }}
    >
      <img
        src={product.image}
        alt={product.nameHi ?? product.name}
        loading="lazy"
        width={512}
        height={512}
        className="h-full w-full object-cover"
      />
    </div>
  );
}
