import { Link } from "@tanstack/react-router";
import { Phone, ShoppingBag, Store } from "lucide-react";
import { useCart } from "@/lib/cart";

export function SiteHeader() {
  const { totalItems } = useCart();
  return (
    <header className="relative overflow-hidden bg-brand text-primary-foreground">
      <div
        className="pointer-events-none absolute inset-0 opacity-30"
        style={{
          backgroundImage:
            "radial-gradient(rgba(255,255,255,0.18) 1.2px, transparent 1.2px)",
          backgroundSize: "22px 22px",
        }}
      />
      <div
        className="absolute inset-x-0 bottom-0 h-2"
        style={{
          background:
            "repeating-linear-gradient(90deg, var(--mustard) 0 18px, var(--brick) 18px 36px)",
        }}
      />
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-5 py-6 sm:py-8">
        <Link to="/" className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-mustard text-foreground shadow-lift">
            <Store className="h-6 w-6" />
          </div>
          <div>
            <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-mustard">
              38+ वर्षों का भरोसा
            </div>
            <h1 className="font-display text-2xl font-extrabold leading-tight sm:text-3xl">
              RS Grocery Shop
            </h1>
          </div>
        </Link>
        <div className="flex items-center gap-2">
          <a
            href="tel:+918239304424"
            className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/10 px-4 py-2 text-sm font-bold backdrop-blur transition hover:bg-white/20"
          >
            <Phone className="h-4 w-4" /> 8239304424
          </a>
          <Link
            to="/cart"
            className="relative inline-flex items-center gap-2 rounded-full bg-primary-foreground px-4 py-2 text-sm font-extrabold text-brand-deep transition hover:opacity-90"
          >
            <ShoppingBag className="h-4 w-4" /> Cart
            {totalItems > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-brick px-1 text-[11px] font-extrabold text-primary-foreground">
                {totalItems}
              </span>
            )}
          </Link>
        </div>
      </div>
    </header>
  );
}
