import { Link } from "@tanstack/react-router";
import { ShoppingCart } from "lucide-react";
import { useCart } from "@/lib/cart";

export function BottomCartBar() {
  const { totalItems, totalPrice } = useCart();
  if (totalItems === 0) return null;

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-40 flex justify-center px-3 pb-3 sm:pb-5">
      <div className="pointer-events-auto flex w-full max-w-3xl items-center justify-between gap-3 rounded-2xl bg-brand-deep px-4 py-3 text-primary-foreground shadow-lift animate-in slide-in-from-bottom-5">
        <div className="flex items-center gap-3">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-mustard text-foreground">
            <ShoppingCart className="h-5 w-5" />
            <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-brick px-1 text-[11px] font-extrabold text-primary-foreground">
              {totalItems}
            </span>
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-wider text-white/70">
              {totalItems} {totalItems === 1 ? "item" : "items"}
            </div>
            <div className="font-display text-lg font-extrabold leading-none">₹{totalPrice}</div>
          </div>
        </div>
        <Link
          to="/cart"
          className="inline-flex items-center gap-2 rounded-xl bg-mustard px-4 py-2.5 text-sm font-extrabold text-foreground transition hover:bg-mustard-deep"
        >
          View Cart →
        </Link>
      </div>
    </div>
  );
}
