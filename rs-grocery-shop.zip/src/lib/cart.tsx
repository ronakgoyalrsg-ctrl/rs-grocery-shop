import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { PRODUCTS, type Product } from "@/data/products";

export type CartItem = { productId: string; qty: number };

type CartCtx = {
  items: CartItem[];
  totalItems: number;
  totalPrice: number;
  getQty: (id: string) => number;
  setQty: (id: string, qty: number) => void;
  addToCart: (id: string, qty: number) => void;
  remove: (id: string) => void;
  clear: () => void;
  detailed: { product: Product; qty: number; lineTotal: number }[];
};

const Ctx = createContext<CartCtx | null>(null);
const KEY = "rs-cart-v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setItems(JSON.parse(raw));
    } catch {}
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(items));
    } catch {}
  }, [items, hydrated]);

  const getQty = useCallback(
    (id: string) => items.find((i) => i.productId === id)?.qty ?? 0,
    [items],
  );

  const setQty = useCallback((id: string, qty: number) => {
    const clamped = Math.max(0, Math.min(10, Math.floor(qty)));
    setItems((prev) => {
      const idx = prev.findIndex((i) => i.productId === id);
      if (clamped === 0) return prev.filter((i) => i.productId !== id);
      if (idx === -1) return [...prev, { productId: id, qty: clamped }];
      const next = [...prev];
      next[idx] = { productId: id, qty: clamped };
      return next;
    });
  }, []);

  const addToCart = useCallback((id: string, qty: number) => {
    setItems((prev) => {
      const idx = prev.findIndex((i) => i.productId === id);
      if (idx === -1) return [...prev, { productId: id, qty: Math.max(1, Math.min(10, qty)) }];
      const next = [...prev];
      next[idx] = { productId: id, qty: Math.min(10, next[idx].qty + qty) };
      return next;
    });
  }, []);

  const remove = useCallback((id: string) => {
    setItems((prev) => prev.filter((i) => i.productId !== id));
  }, []);

  const clear = useCallback(() => setItems([]), []);

  const detailed = useMemo(() => {
    return items
      .map((i) => {
        const p = PRODUCTS.find((p) => p.id === i.productId);
        if (!p) return null;
        return { product: p, qty: i.qty, lineTotal: p.price * i.qty };
      })
      .filter(Boolean) as { product: Product; qty: number; lineTotal: number }[];
  }, [items]);

  const totalItems = useMemo(() => items.reduce((s, i) => s + i.qty, 0), [items]);
  const totalPrice = useMemo(() => detailed.reduce((s, d) => s + d.lineTotal, 0), [detailed]);

  const value: CartCtx = {
    items,
    totalItems,
    totalPrice,
    getQty,
    setQty,
    addToCart,
    remove,
    clear,
    detailed,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useCart must be used within CartProvider");
  return v;
}

export const WHATSAPP_NUMBER = "918239304424";

export function buildWhatsappOrder(
  detailed: { product: Product; qty: number; lineTotal: number }[],
  total: number,
) {
  const lines = detailed.map(
    (d, i) =>
      `${i + 1}. ${d.product.name} (${d.product.nameHi ?? ""}) — ${d.qty} ${d.product.unit} × ₹${d.product.price} = ₹${d.lineTotal}`,
  );
  const msg = [
    "नमस्ते RS Grocery,",
    "मुझे यह ऑर्डर चाहिए:",
    "",
    ...lines,
    "",
    `कुल: ₹${total}`,
    "कृपया कन्फर्म करें। धन्यवाद!",
  ].join("\n");
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
}
