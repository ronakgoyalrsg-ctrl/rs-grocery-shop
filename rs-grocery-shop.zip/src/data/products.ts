import basmatiRice from "@/assets/products/basmati-rice.jpg";
import sonaMasoori from "@/assets/products/sona-masoori.jpg";
import wheatAtta from "@/assets/products/wheat-atta.jpg";
import maida from "@/assets/products/maida.jpg";
import besan from "@/assets/products/besan.jpg";
import sooji from "@/assets/products/sooji.jpg";
import toorDal from "@/assets/products/toor-dal.jpg";
import moongDal from "@/assets/products/moong-dal.jpg";
import chanaDal from "@/assets/products/chana-dal.jpg";
import uradDal from "@/assets/products/urad-dal.jpg";
import rajma from "@/assets/products/rajma.jpg";
import chole from "@/assets/products/chole.jpg";
import sunflowerOil from "@/assets/products/sunflower-oil.jpg";
import mustardOil from "@/assets/products/mustard-oil.jpg";
import desiGhee from "@/assets/products/desi-ghee.jpg";
import sugar from "@/assets/products/sugar.jpg";
import salt from "@/assets/products/salt.jpg";
import jaggery from "@/assets/products/jaggery.jpg";
import haldi from "@/assets/products/haldi.jpg";
import chilli from "@/assets/products/chilli.jpg";
import dhaniya from "@/assets/products/dhaniya.jpg";
import garamMasala from "@/assets/products/garam-masala.jpg";
import jeera from "@/assets/products/jeera.jpg";
import almonds from "@/assets/products/almonds.jpg";
import cashews from "@/assets/products/cashews.jpg";
import raisins from "@/assets/products/raisins.jpg";
import tea from "@/assets/products/tea.jpg";
import poha from "@/assets/products/poha.jpg";
import vermicelli from "@/assets/products/vermicelli.jpg";

export type Category =
  | "grains"
  | "dals"
  | "oils"
  | "sugar-salt"
  | "spices"
  | "dry-fruits"
  | "others";

export type Product = {
  id: string;
  name: string;
  nameHi?: string;
  category: Category;
  unit: "kg" | "pcs";
  price: number; // per unit
  tint: string;
  image: string;
};

export const CATEGORIES: { id: Category | "all"; label: string }[] = [
  { id: "all", label: "सभी" },
  { id: "grains", label: "अनाज व आटा" },
  { id: "dals", label: "दालें" },
  { id: "oils", label: "तेल व घी" },
  { id: "sugar-salt", label: "चीनी व नमक" },
  { id: "spices", label: "मसाले" },
  { id: "dry-fruits", label: "ड्राई फ्रूट्स" },
  { id: "others", label: "अन्य" },
];

export const PRODUCTS: Product[] = [
  { id: "basmati-rice", name: "Basmati Rice", nameHi: "बासमती चावल", category: "grains", unit: "kg", price: 40, tint: "oklch(0.95 0.03 90)", image: basmatiRice },
  { id: "sona-masoori", name: "Sona Masoori Rice", nameHi: "सोना मसूरी", category: "grains", unit: "kg", price: 55, tint: "oklch(0.94 0.04 85)", image: sonaMasoori },
  { id: "wheat-atta", name: "Wheat Atta", nameHi: "गेहूँ आटा", category: "grains", unit: "kg", price: 45, tint: "oklch(0.9 0.05 75)", image: wheatAtta },
  { id: "maida", name: "Maida", nameHi: "मैदा", category: "grains", unit: "kg", price: 40, tint: "oklch(0.96 0.015 90)", image: maida },
  { id: "besan", name: "Besan", nameHi: "बेसन", category: "grains", unit: "kg", price: 90, tint: "oklch(0.87 0.11 88)", image: besan },
  { id: "sooji", name: "Sooji / Rava", nameHi: "सूजी", category: "grains", unit: "kg", price: 50, tint: "oklch(0.93 0.04 88)", image: sooji },

  { id: "toor-dal", name: "Toor Dal", nameHi: "तूर दाल", category: "dals", unit: "kg", price: 140, tint: "oklch(0.83 0.13 85)", image: toorDal },
  { id: "moong-dal", name: "Moong Dal", nameHi: "मूंग दाल", category: "dals", unit: "kg", price: 120, tint: "oklch(0.82 0.13 110)", image: moongDal },
  { id: "chana-dal", name: "Chana Dal", nameHi: "चना दाल", category: "dals", unit: "kg", price: 90, tint: "oklch(0.8 0.14 82)", image: chanaDal },
  { id: "urad-dal", name: "Urad Dal", nameHi: "उड़द दाल", category: "dals", unit: "kg", price: 130, tint: "oklch(0.88 0.02 80)", image: uradDal },
  { id: "rajma", name: "Rajma", nameHi: "राजमा", category: "dals", unit: "kg", price: 150, tint: "oklch(0.6 0.14 30)", image: rajma },
  { id: "chole", name: "Chole", nameHi: "छोले", category: "dals", unit: "kg", price: 110, tint: "oklch(0.78 0.12 75)", image: chole },

  { id: "sunflower-oil", name: "Sunflower Oil", nameHi: "सूरजमुखी तेल", category: "oils", unit: "kg", price: 150, tint: "oklch(0.88 0.13 95)", image: sunflowerOil },
  { id: "mustard-oil", name: "Mustard Oil", nameHi: "सरसों तेल", category: "oils", unit: "kg", price: 170, tint: "oklch(0.78 0.15 80)", image: mustardOil },
  { id: "desi-ghee", name: "Desi Ghee", nameHi: "देसी घी", category: "oils", unit: "kg", price: 550, tint: "oklch(0.85 0.12 85)", image: desiGhee },

  { id: "sugar", name: "Sugar", nameHi: "चीनी", category: "sugar-salt", unit: "kg", price: 45, tint: "oklch(0.97 0.01 90)", image: sugar },
  { id: "salt", name: "Salt", nameHi: "नमक", category: "sugar-salt", unit: "kg", price: 25, tint: "oklch(0.98 0.005 200)", image: salt },
  { id: "jaggery", name: "Jaggery / Gur", nameHi: "गुड़", category: "sugar-salt", unit: "kg", price: 60, tint: "oklch(0.55 0.13 55)", image: jaggery },

  { id: "haldi", name: "Turmeric", nameHi: "हल्दी", category: "spices", unit: "kg", price: 220, tint: "oklch(0.78 0.17 80)", image: haldi },
  { id: "chilli", name: "Red Chilli Powder", nameHi: "लाल मिर्च", category: "spices", unit: "kg", price: 280, tint: "oklch(0.55 0.19 30)", image: chilli },
  { id: "dhaniya", name: "Coriander Powder", nameHi: "धनिया", category: "spices", unit: "kg", price: 200, tint: "oklch(0.6 0.1 90)", image: dhaniya },
  { id: "garam-masala", name: "Garam Masala", nameHi: "गरम मसाला", category: "spices", unit: "kg", price: 450, tint: "oklch(0.42 0.08 55)", image: garamMasala },
  { id: "jeera", name: "Cumin (Jeera)", nameHi: "जीरा", category: "spices", unit: "kg", price: 380, tint: "oklch(0.55 0.09 65)", image: jeera },

  { id: "almonds", name: "Almonds", nameHi: "बादाम", category: "dry-fruits", unit: "kg", price: 700, tint: "oklch(0.7 0.08 60)", image: almonds },
  { id: "cashews", name: "Cashews", nameHi: "काजू", category: "dry-fruits", unit: "kg", price: 850, tint: "oklch(0.88 0.05 85)", image: cashews },
  { id: "raisins", name: "Raisins", nameHi: "किशमिश", category: "dry-fruits", unit: "kg", price: 280, tint: "oklch(0.58 0.1 55)", image: raisins },

  { id: "tea", name: "Tea", nameHi: "चाय पत्ती", category: "others", unit: "kg", price: 320, tint: "oklch(0.4 0.08 55)", image: tea },
  { id: "poha", name: "Poha", nameHi: "पोहा", category: "others", unit: "kg", price: 60, tint: "oklch(0.95 0.02 90)", image: poha },
  { id: "vermicelli", name: "Vermicelli", nameHi: "सेवई", category: "others", unit: "kg", price: 80, tint: "oklch(0.87 0.07 85)", image: vermicelli },
];
