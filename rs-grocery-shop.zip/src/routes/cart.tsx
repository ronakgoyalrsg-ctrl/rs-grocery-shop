import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, Trash2 } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { QuantityStepper } from "@/components/QuantityStepper";
import { ProductImage } from "@/components/ProductImage";
import { useCart } from "@/lib/cart";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "आपका कार्ट — RS Grocery Shop" },
      { name: "description", content: "अपने कार्ट में शामिल grocery items देखें और ऑर्डर पक्का करें।" },
      { property: "og:title", content: "Your Cart — RS Grocery Shop" },
      { property: "og:description", content: "Review your grocery items and place your order." },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const { detailed, setQty, remove, totalItems, totalPrice, clear } = useCart();
  const navigate = useNavigate();

  return (
    <>
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-5 pb-24 pt-8">
        <Link to="/" className="mb-4 inline-flex items-center gap-1 text-sm font-semibold text-brand-deep">
          <ArrowLeft className="h-4 w-4" /> Continue shopping
        </Link>
        <h2 className="font-display text-3xl font-extrabold text-brand-deep">आपका कार्ट</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          {totalItems === 0 ? "कार्ट खाली है।" : `${totalItems} items · ₹${totalPrice}`}
        </p>

        {detailed.length === 0 ? (
          <div className="mt-8 rounded-2xl border border-border bg-card p-12 text-center shadow-soft">
            <p className="text-muted-foreground">Add items from the shop to see them here.</p>
            <Link
              to="/"
              className="mt-4 inline-flex rounded-lg bg-brand px-5 py-2.5 text-sm font-bold text-primary-foreground"
            >
              Browse products
            </Link>
          </div>
        ) : (
          <>
            <ul className="mt-6 flex flex-col gap-3">
              {detailed.map(({ product, qty, lineTotal }) => (
                <li
                  key={product.id}
                  className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3 shadow-soft"
                >
                  <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl">
                    <ProductImage product={product} size={64} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-display font-bold">{product.nameHi ?? product.name}</div>
                    <div className="text-xs text-muted-foreground">
                      ₹{product.price}/{product.unit} · {product.name}
                    </div>
                    <div className="mt-1 font-display text-sm font-extrabold text-brand-deep">
                      ₹{lineTotal}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <QuantityStepper value={qty} onChange={(v) => setQty(product.id, v)} />
                    <button
                      onClick={() => remove(product.id)}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-brick hover:underline"
                    >
                      <Trash2 className="h-3.5 w-3.5" /> Remove
                    </button>
                  </div>
                </li>
              ))}
            </ul>

            <div className="mt-6 rounded-2xl border border-border bg-card p-5 shadow-soft">
              <div className="flex items-center justify-between">
                <span className="font-semibold">कुल राशि</span>
                <span className="font-display text-2xl font-extrabold text-brand-deep">₹{totalPrice}</span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                यह अनुमानित राशि है। ऑर्डर कन्फर्म करने के बाद टीम पुष्टि करेगी।
              </p>
              <div className="mt-4 flex flex-col-reverse gap-2 sm:flex-row sm:justify-between">
                <button
                  onClick={() => clear()}
                  className="rounded-lg border border-border px-4 py-2.5 text-sm font-semibold text-muted-foreground hover:bg-muted"
                >
                  Clear cart
                </button>
                <button
                  onClick={() => navigate({ to: "/checkout" })}
                  className="rounded-lg bg-brick px-6 py-3 text-sm font-extrabold text-primary-foreground transition hover:bg-brick-deep"
                >
                  Checkout →
                </button>
              </div>
            </div>
          </>
        )}
      </main>
    </>
  );
}
