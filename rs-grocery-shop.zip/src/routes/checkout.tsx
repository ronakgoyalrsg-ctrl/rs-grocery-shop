import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle2, MessageCircle } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { buildWhatsappOrder, useCart } from "@/lib/cart";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout — RS Grocery Shop" },
      { name: "description", content: "अपना ऑर्डर कन्फर्म करें और WhatsApp पर भेजें।" },
      { property: "og:title", content: "Checkout — RS Grocery Shop" },
      { property: "og:description", content: "Confirm your order and send it via WhatsApp." },
    ],
  }),
  component: CheckoutPage,
});

function CheckoutPage() {
  const { detailed, totalItems, totalPrice, clear } = useCart();
  const [placed, setPlaced] = useState(false);
  const [orderId] = useState(() => "RS" + Math.floor(100000 + Math.random() * 900000));
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");

  const waLink = useMemo(() => buildWhatsappOrder(detailed, totalPrice), [detailed, totalPrice]);

  if (placed) {
    return (
      <>
        <SiteHeader />
        <main className="mx-auto max-w-xl px-5 py-12">
          <div className="rounded-2xl border border-border bg-card p-8 text-center shadow-soft">
            <CheckCircle2 className="mx-auto h-14 w-14 text-brand" />
            <h2 className="mt-4 font-display text-2xl font-extrabold text-brand-deep">
              धन्यवाद, {name || "ग्राहक"}!
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              आपका ऑर्डर <b>#{orderId}</b> प्राप्त हो गया है। हम जल्दी ही आपसे संपर्क करेंगे।
            </p>
            <a
              href={waLink}
              target="_blank"
              rel="noreferrer"
              className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#25D366] px-5 py-3 text-sm font-extrabold text-white"
            >
              <MessageCircle className="h-4 w-4" /> WhatsApp पर भेजें
            </a>
            <div className="mt-4">
              <Link to="/" className="text-sm font-semibold text-brand-deep hover:underline">
                होम पर वापस जाएँ →
              </Link>
            </div>
          </div>
        </main>
      </>
    );
  }

  return (
    <>
      <SiteHeader />
      <main className="mx-auto grid max-w-4xl gap-6 px-5 py-8 md:grid-cols-[1fr_360px]">
        <section>
          <h2 className="font-display text-3xl font-extrabold text-brand-deep">Checkout</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            नीचे अपनी जानकारी भरें। ऑर्डर पक्का करने के लिए हम WhatsApp पर पुष्टि करेंगे।
          </p>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (detailed.length === 0) return;
              setPlaced(true);
              clear();
            }}
            className="mt-6 space-y-4 rounded-2xl border border-border bg-card p-5 shadow-soft"
          >
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                नाम
              </label>
              <input
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2.5 outline-none focus:border-mustard focus:ring-2 focus:ring-mustard/30"
                placeholder="Your name"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                फोन नंबर
              </label>
              <input
                required
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2.5 outline-none focus:border-mustard focus:ring-2 focus:ring-mustard/30"
                placeholder="10-digit mobile"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                पता (Optional — for delivery)
              </label>
              <textarea
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                rows={3}
                className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2.5 outline-none focus:border-mustard focus:ring-2 focus:ring-mustard/30"
                placeholder="House, street, area"
              />
            </div>
            <button
              type="submit"
              disabled={detailed.length === 0}
              className="w-full rounded-xl bg-brick py-3.5 text-sm font-extrabold text-primary-foreground transition hover:bg-brick-deep disabled:opacity-50"
            >
              Place Order · ₹{totalPrice}
            </button>
          </form>
        </section>

        <aside>
          <div className="sticky top-6 rounded-2xl border border-border bg-card p-5 shadow-soft">
            <h3 className="font-display text-lg font-extrabold text-brand-deep">Order summary</h3>
            {detailed.length === 0 ? (
              <p className="mt-3 text-sm text-muted-foreground">
                कार्ट खाली है।{" "}
                <Link to="/" className="font-semibold text-brand-deep underline">
                  Shop करें
                </Link>
                .
              </p>
            ) : (
              <>
                <ul className="mt-3 space-y-2 text-sm">
                  {detailed.map(({ product, qty, lineTotal }) => (
                    <li key={product.id} className="flex justify-between gap-2">
                      <span className="min-w-0 truncate">
                        {product.nameHi ?? product.name}
                        <span className="text-muted-foreground"> × {qty}</span>
                      </span>
                      <span className="font-semibold">₹{lineTotal}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-3 flex justify-between border-t border-border pt-3 text-sm">
                  <span>Items</span>
                  <span>{totalItems}</span>
                </div>
                <div className="mt-1 flex justify-between font-display text-lg font-extrabold text-brand-deep">
                  <span>Total</span>
                  <span>₹{totalPrice}</span>
                </div>
              </>
            )}
          </div>
        </aside>
      </main>
    </>
  );
}
