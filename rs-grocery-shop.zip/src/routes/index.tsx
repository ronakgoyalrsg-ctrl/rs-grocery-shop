import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { ProductCard } from "@/components/ProductCard";
import { BottomCartBar } from "@/components/BottomCartBar";
import { Testimonials } from "@/components/Testimonials";
import { CATEGORIES, PRODUCTS, type Category } from "@/data/products";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "RS Grocery Shop — राशन, मसाले, तेल-घी ऑनलाइन ऑर्डर करें" },
      {
        name: "description",
        content:
          "RS Grocery Shop पर बासमती चावल, दालें, मसाले, तेल-घी और रोज़मर्रा का सामान ऑर्डर करें। 38+ वर्षों का भरोसा।",
      },
      { property: "og:title", content: "RS Grocery Shop — Trusted Neighborhood Grocery" },
      {
        property: "og:description",
        content:
          "Order rice, dals, spices, oils and daily grocery essentials with quantity-based pricing. 38+ years of trust.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  const [cat, setCat] = useState<Category | "all">("all");
  const [q, setQ] = useState("");

  const filtered = PRODUCTS.filter(
    (p) =>
      (cat === "all" || p.category === cat) &&
      (q.trim() === "" ||
        p.name.toLowerCase().includes(q.toLowerCase()) ||
        (p.nameHi ?? "").includes(q)),
  );

  return (
    <>
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-5 pb-32 pt-8">
        <div className="mb-6">
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search rice, dal, masala…"
            className="w-full rounded-2xl border border-border bg-card px-5 py-3.5 text-base shadow-soft outline-none transition focus:border-mustard focus:ring-4 focus:ring-mustard/25"
          />
        </div>

        <div className="scrollbar-none -mx-1 mb-6 flex gap-2 overflow-x-auto px-1">
          {CATEGORIES.map((c) => {
            const active = c.id === cat;
            return (
              <button
                key={c.id}
                onClick={() => setCat(c.id)}
                className={
                  "shrink-0 rounded-full border px-4 py-2 text-sm font-bold transition " +
                  (active
                    ? "border-brand bg-brand text-primary-foreground shadow-soft"
                    : "border-border bg-card text-foreground hover:border-brand/40")
                }
              >
                {c.label}
              </button>
            );
          })}
        </div>

        {filtered.length === 0 ? (
          <div className="rounded-2xl border border-border bg-card p-12 text-center text-muted-foreground shadow-soft">
            कोई प्रोडक्ट नहीं मिला।
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}

        <Testimonials />
      </main>
      <BottomCartBar />
    </>
  );
}
